/**
 * PA3ifdots.java
 *
 * An example for the students to code up in AVR assembly for PA1.
 * The language features will be from the PA3 grammar.
 *
 * MMS, 1/23/13
 */

import meggy.Meggy;

class PA3ifdots {

    public static void main(String[] whatever){
            //
            //if(true && false){
                Meggy.setPixel((byte)((byte)0*(byte)0), (byte)1, Meggy.Color.RED);
            //}

    }
}
