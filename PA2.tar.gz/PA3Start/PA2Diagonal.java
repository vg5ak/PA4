


import meggy.Meggy;

class PA2Diagonal {
	public static void main(String[] whatever){
	        // Lower left petal, clockwise

            Meggy.setPixel( (byte)1, (byte)1, Meggy.Color.VIOLET );

    }
}
