

import meggy.Meggy;


class PA3Test2 {

    public static void main(String[] whatever){
        Meggy.setPixel((byte)4, (byte)4, Meggy.Color.RED);
        if(!true){
            Meggy.setPixel( (byte)0, (byte)0, Meggy.Color.RED );
            Meggy.setPixel( (byte)7, (byte)0, Meggy.Color.GREEN );

        }
        else if (Meggy.checkButton(Meggy.Button.Up)) {
                Meggy.setPixel( (byte)0, (byte)0, Meggy.getPixel((byte)2, (byte)2) );
                Meggy.setPixel( (byte)6, (byte)6, Meggy.Color.ORANGE );
                Meggy.setPixel( (byte)2, (byte)2, Meggy.Color.BLUE );


        }
        else if(false) {
                Meggy.setPixel( (byte)1, (byte)1, Meggy.Color.BLUE );
                Meggy.setPixel( (byte)6, (byte)1, Meggy.Color.VIOLET );
        }
        else{
            Meggy.setPixel( (byte)6, (byte)6, Meggy.Color.ORANGE );
        }

    }
}
